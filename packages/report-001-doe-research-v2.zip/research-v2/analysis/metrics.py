#!/usr/bin/env python3
"""Offline DOE analysis helpers. No calibration, implicit corrections or network."""
import argparse
import csv
import json
import math
from pathlib import Path
import statistics


def finite(value):
    v = float(value)
    if not math.isfinite(v):
        raise ValueError('NaN/Inf is not accepted')
    return v


def power(path):
    fields = ['measurement_id', 'target_mw', 'target_bg_mw',
              'reference_mw', 'reference_bg_mw']
    ratios, ids = [], set()
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != fields:
            raise ValueError('Power CSV header/order must match README')
        for row in reader:
            if None in row or any(v is None for v in row.values()):
                raise ValueError('Malformed power CSV row')
            label = row['measurement_id'].strip()
            if not label or label in ids:
                raise ValueError('Empty/duplicate measurement_id')
            ids.add(label)
            t, tb, r, rb = [finite(row[k]) for k in fields[1:]]
            if min(t, tb, r, rb) < 0 or t < tb or r <= rb:
                raise ValueError('Require nonnegative readings/backgrounds, net target>=0, net reference>0')
            ratios.append((t - tb) / (r - rb))
    if not ratios:
        raise ValueError('No power rows')
    n = len(ratios)
    sd = statistics.stdev(ratios) if n > 1 else None
    return {'n_pairs': n, 'pair_ratios': ratios,
            'mean_of_paired_ratios': statistics.mean(ratios),
            'sample_standard_deviation': sd,
            'type_A_standard_uncertainty_of_mean': sd / math.sqrt(n) if sd is not None else None,
            'ratios_above_one': sum(r > 1 for r in ratios),
            'interpretation': 'Target/reference net-power ratio; define reference plane externally. No B-type uncertainty or drift correction.'}


def matrix(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        result = [[finite(v) for v in row] for row in csv.reader(f)]
    if not result or not result[0] or any(len(row) != len(result[0]) for row in result):
        raise ValueError('Matrix must be nonempty rectangular CSV without header')
    return result


def image(raw_path, dark_path, mask_path, target_path=None, saturation=None):
    raw, dark, mask = [matrix(p) for p in (raw_path, dark_path, mask_path)]
    h, w = len(raw), len(raw[0])
    if any(len(m) != h or len(m[0]) != w for m in (dark, mask)):
        raise ValueError('Raw/dark/mask shapes differ')
    rawf, darkf, maskf = [[v for row in m for v in row] for m in (raw, dark, mask)]
    if any(v < 0 for v in rawf + darkf):
        raise ValueError('Raw/dark DN must be nonnegative')
    if any(v not in (0, 1) for v in maskf) or not any(maskf):
        raise ValueError('Mask must contain only 0/1 and at least one 1')
    if saturation is not None:
        saturation = finite(saturation)
        if saturation <= 0 or any(v >= saturation for v in rawf):
            raise ValueError('Invalid saturation threshold or saturated pixel; inspect original data')
    net = [a - b for a, b in zip(rawf, darkf)]
    if any(v < 0 for v in net):
        raise ValueError('Negative background-corrected signal; no silent clipping supported')
    total = math.fsum(net)
    selected = [s * m for s, m in zip(net, maskf)]
    roi = math.fsum(selected)
    if total <= 0 or roi <= 0:
        raise ValueError('Net frame and ROI sums must be positive')
    result = {'shape_yx': [h, w], 'full_frame_net_sum_DN': total,
              'roi_net_sum_DN': roi, 'roi_fraction_of_recorded_frame': roi / total,
              'roi_centroid_x_pixel': math.fsum((i % w) * v for i, v in enumerate(selected)) / roi,
              'roi_centroid_y_pixel': math.fsum((i // w) * v for i, v in enumerate(selected)) / roi,
              'saturation_checked': saturation is not None,
              'interpretation': 'Relative DN only; centroid uses zero-based pixel centres in selected ROI. No absolute efficiency.'}
    if target_path is not None:
        target = matrix(target_path)
        if len(target) != h or len(target[0]) != w:
            raise ValueError('Target shape differs')
        tf = [v for row in target for v in row]
        ts = math.fsum(tf)
        if any(v < 0 for v in tf) or ts <= 0:
            raise ValueError('Target intensity must be nonnegative with positive sum')
        count = h * w
        mse = math.fsum((a / total - b / ts) ** 2 for a, b in zip(net, tf)) / count
        result['NRMSE_norm_full_frame'] = math.sqrt(mse) * count
    return result


def spots(path):
    values = [v for row in matrix(path) for v in row]
    if len(values) < 2 or min(values) < 0 or statistics.mean(values) <= 0:
        raise ValueError('Need >=2 nonnegative spot integrals and a positive mean')
    mean = statistics.mean(values)
    return {'n_spots': len(values), 'mean': mean,
            'CV_spot_sample': statistics.stdev(values) / mean,
            'U_range': 1 - (max(values) - min(values)) / (max(values) + min(values)),
            'interpretation': 'Equal-target-weight spot integrals, not temporal uncertainty. See README.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    power_p = sub.add_parser('power')
    power_p.add_argument('--csv', required=True)
    image_p = sub.add_parser('image')
    for name in ('raw', 'dark', 'mask'):
        image_p.add_argument('--' + name, required=True)
    image_p.add_argument('--target')
    image_p.add_argument('--saturation', type=float)
    spot_p = sub.add_parser('spots')
    spot_p.add_argument('--csv', required=True)
    for pp in (power_p, image_p, spot_p):
        pp.add_argument('--output', required=True)
    a = p.parse_args()
    try:
        if a.command == 'power':
            result = power(a.csv)
        elif a.command == 'spots':
            result = spots(a.csv)
        else:
            result = image(a.raw, a.dark, a.mask, a.target, a.saturation)
        out = Path(a.output)
        inputs = [getattr(a, k, None) for k in ('csv', 'raw', 'dark', 'mask', 'target')]
        if out.suffix.lower() != '.json' or out.exists() or out.is_symlink():
            raise ValueError('Output must be a new .json file; will not overwrite')
        if out.resolve() in [Path(x).resolve() for x in inputs if x]:
            raise ValueError('Output cannot replace input')
        payload = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
        with out.open('x', encoding='utf-8') as f:
            f.write(payload)
        print('PASS: analysis written; interpretation/calibration remain operator responsibilities')
        return 0
    except (OSError, ValueError, TypeError, OverflowError) as e:
        print('FAIL:', e)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
