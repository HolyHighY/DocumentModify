"""Offline known-answer and rejection tests, using synthetic inputs only."""
import contextlib
import io
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import metrics
from gs_scalar_demo import demo


class KnownAnswers(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def write(self, name, text):
        f = self.root / name
        f.write_text(text, encoding='utf-8')
        return f

    def power_csv(self, rows):
        return self.write('power.csv', 'measurement_id,target_mw,target_bg_mw,reference_mw,reference_bg_mw\n'+rows)

    def test_power_known_answer(self):
        p = self.power_csv('s1,5,1,11,1\ns2,7,1,11,1\n')
        r = metrics.power(p)
        self.assertEqual(r['pair_ratios'], [0.4,0.6])
        self.assertAlmostEqual(r['mean_of_paired_ratios'], 0.5)
        self.assertAlmostEqual(r['sample_standard_deviation'], math.sqrt(.02))
        self.assertAlmostEqual(r['type_A_standard_uncertainty_of_mean'], .1)

    def test_one_pair_not_false_uncertainty(self):
        r = metrics.power(self.power_csv('s1,5,1,11,1\n'))
        self.assertIsNone(r['sample_standard_deviation'])

    def test_invalid_power(self):
        for rows in ['', 's1,5,1,1,1\n', 's1,nan,0,1,0\n',
                     's1,0,1,2,0\n', 's1,1,0,2,0\ns1,1,0,2,0\n',
                     's1,1,0,2\n', 's1,1,0,2,0,extra\n']:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                metrics.power(self.power_csv(rows))

    def images(self):
        return [self.write(n,t) for n,t in [('raw.csv','3,1\n1,5\n'),
                 ('dark.csv','1,1\n1,1\n'),('mask.csv','0,0\n0,1\n'),
                 ('target.csv','2,0\n0,4\n')]]

    def test_image_known_answer(self):
        raw,dark,mask,target = self.images()
        r = metrics.image(raw,dark,mask,target,saturation=255)
        self.assertEqual(r['full_frame_net_sum_DN'],6)
        self.assertAlmostEqual(r['roi_fraction_of_recorded_frame'],2/3)
        self.assertEqual(r['roi_centroid_x_pixel'],1)
        self.assertEqual(r['roi_centroid_y_pixel'],1)
        self.assertEqual(r['NRMSE_norm_full_frame'],0)
        different = self.write('different.csv','4,0\n0,2\n')
        self.assertAlmostEqual(metrics.image(raw,dark,mask,different)['NRMSE_norm_full_frame'],math.sqrt(8/9))

    def test_invalid_image(self):
        raw,dark,mask,target = self.images()
        with self.assertRaises(ValueError):
            metrics.image(raw,dark,mask,target,saturation=5)
        for name,text in [('negative.csv','9,9\n9,9\n'),('shape.csv','1\n'),
                          ('ragged.csv','1,1\n1\n'),('nan.csv','nan,1\n1,1\n')]:
            with self.subTest(name=name), self.assertRaises(ValueError):
                metrics.image(raw,self.write(name,text),mask)
        for text in ['0,0\n0,0\n','0,0\n0,0.5\n']:
            with self.subTest(mask=text), self.assertRaises(ValueError):
                metrics.image(raw,dark,self.write('badmask.csv',text))
        with self.assertRaises(ValueError):
            metrics.image(raw,raw,mask)

    def test_spot_metrics(self):
        r=metrics.spots(self.write('spots.csv','2,4\n'))
        self.assertAlmostEqual(r['CV_spot_sample'],math.sqrt(2)/3)
        self.assertAlmostEqual(r['U_range'],2/3)
        for text in ['0,0\n','-1,2\n','1\n']:
            with self.assertRaises(ValueError):
                metrics.spots(self.write('badspots.csv',text))

    def test_dft_gs_analytical_benchmark(self):
        r=demo()
        self.assertEqual(r['actual_peak_yx'],[1,2])
        self.assertLess(r['GS_amplitude_l2_error_trace'][-1],1e-10)
        with self.assertRaises(ValueError):
            demo(n=1000)

    def test_cli_status_and_no_overwrite(self):
        tool=Path(metrics.__file__).resolve()
        inp=self.power_csv('s1,5,1,11,1\n')
        out=self.root/'out.json'
        cmd=[sys.executable,str(tool),'power','--csv',str(inp),'--output',str(out)]
        r=subprocess.run(cmd,capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        before=out.read_bytes()
        self.assertEqual(subprocess.run(cmd,capture_output=True).returncode,1)
        self.assertEqual(out.read_bytes(),before)
        inp=self.power_csv('s1,5,1,1,1\n')
        out.unlink()
        self.assertEqual(subprocess.run(cmd,capture_output=True).returncode,1)
        self.assertFalse(out.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
