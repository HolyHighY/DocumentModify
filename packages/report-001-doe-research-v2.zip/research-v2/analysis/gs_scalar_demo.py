#!/usr/bin/env python3
"""SYNTHETIC ONLY: tiny unitary DFT/GS teaching example, not DOE validation."""
import argparse
import cmath
import json
import math
from pathlib import Path
import random


def dft2(a, inverse=False):
    n = len(a)
    sign = 1 if inverse else -1
    scale = math.sqrt(n)
    tmp = [[sum(a[y][x] * cmath.exp(sign * 2j * math.pi * k * x / n)
                for x in range(n)) / scale for k in range(n)] for y in range(n)]
    return [[sum(tmp[y][x] * cmath.exp(sign * 2j * math.pi * k * y / n)
                 for y in range(n)) / scale for x in range(n)] for k in range(n)]


def demo(n=8, iterations=4, seed=7):
    if not 4 <= n <= 32 or not 1 <= iterations <= 100:
        raise ValueError('Teaching workload: 4<=size<=32, 1<=iterations<=100')
    kx, ky = 2, 1
    blaze = [[cmath.exp(2j * math.pi * (kx*x + ky*y) / n) / n
              for x in range(n)] for y in range(n)]
    v = dft2(blaze)
    back = dft2(v, inverse=True)
    rt_error = max(abs(a-b) for ra, rb in zip(blaze, back) for a, b in zip(ra, rb))
    energy = sum(abs(x)**2 for row in v for x in row)
    peak = max(((abs(v[y][x])**2, y, x) for y in range(n) for x in range(n)))
    rng = random.Random(seed)
    u = [[cmath.exp(1j*rng.uniform(-math.pi, math.pi))/n for x in range(n)] for y in range(n)]
    trace = []
    for step in range(iterations+1):
        far = dft2(u)
        error = math.sqrt(sum((abs(far[y][x]) - (1 if (y,x)==(ky,kx) else 0))**2
                              for y in range(n) for x in range(n)))
        trace.append(error)
        if step == iterations:
            break
        constrained = [[0j]*n for _ in range(n)]
        constrained[ky][kx] = cmath.exp(1j*cmath.phase(far[ky][kx]))
        near = dft2(constrained, inverse=True)
        u = [[cmath.exp(1j*cmath.phase(x))/n for x in row] for row in near]
    if rt_error > 1e-10 or abs(energy-1) > 1e-10 or peak[1:] != (ky,kx) or trace[-1] > 1e-10:
        raise ValueError('Synthetic analytical benchmark failed')
    return {'synthetic_only': True, 'size': n, 'seed': seed, 'iterations': iterations,
            'model': 'unitary discrete Fourier-plane scalar model; unshifted frequency indices',
            'DFT_roundtrip_max_error': rt_error, 'output_energy_for_unit_input': energy,
            'analytic_blaze_expected_peak_yx': [ky,kx], 'actual_peak_yx': list(peak[1:]),
            'GS_target_single_bin_yx': [ky,kx], 'GS_amplitude_l2_error_trace': trace,
            'limitation': 'A trivial one-spot test. Not general GS convergence, a real phase design, full optical train or independent scalar-model validation.'}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--size', type=int, default=8)
    p.add_argument('--iterations', type=int, default=4)
    p.add_argument('--seed', type=int, default=7)
    p.add_argument('--output', required=True)
    args = p.parse_args()
    try:
        out = Path(args.output)
        if out.suffix.lower() != '.json' or out.exists() or out.is_symlink():
            raise ValueError('Use a new .json output; no overwrite')
        result = demo(args.size, args.iterations, args.seed)
        with out.open('x', encoding='utf-8') as f:
            f.write(json.dumps(result, indent=2, allow_nan=False)+'\n')
        print('PASS: synthetic Fourier/GS benchmark only')
    except (OSError, ValueError, OverflowError) as e:
        print('FAIL:', e)
        raise SystemExit(1)
