# 离线分析：输入约定、命令与边界

本包脚本为新写辅助方法，仅Python标准库；外网验证Python 3.12.14。没有第三方包、模型、字体或联网依赖；没有准备跨平台wheel。目标内网Python版本仍需实测。所有 `synthetic/` 输入都是合成数据，必须排除出正式结果。

## 运行（从research-v2包根目录）

Windows仅有启动器时将python替换为py -3。输出写到包外新目录；脚本拒绝覆盖已有结果。先执行：

```sh
python -c "from pathlib import Path; Path('../report-001-analysis-run').mkdir(exist_ok=False)"
python -B -m unittest discover -s analysis -p test_analysis.py -v
python -B analysis/metrics.py power --csv analysis/synthetic/power.csv --output ../report-001-analysis-run/power.json
python -B analysis/metrics.py image --raw analysis/synthetic/raw.csv --dark analysis/synthetic/dark.csv --mask analysis/synthetic/mask.csv --target analysis/synthetic/target.csv --saturation 255 --output ../report-001-analysis-run/image.json
python -B analysis/metrics.py spots --csv analysis/synthetic/spots.csv --output ../report-001-analysis-run/spots.json
python -B analysis/gs_scalar_demo.py --size 8 --iterations 4 --seed 7 --output ../report-001-analysis-run/gs.json
```

已有同名运行目录时另取新名，不删除旧结果重跑。所有命令应退出0；输入不适用则失败（退出1），不可把失败输出当作结果文件。-B避免向冻结包写入__pycache__。

## 输入字段与有效范围

### power：配对功率

UTF-8 CSV，标题和顺序严格为：
`measurement_id,target_mw,target_bg_mw,reference_mw,reference_bg_mw`

- 每行是同条件的一组目标/参考读数与对应背景，单位全部mW，数值必须有限、非负；ID非空且唯一。不得将W值直接填到mW字段。
- 净目标≥0、净参考>0；缺失/NaN/Inf/多列/少列拒绝。暗场/参考适用性、时间配对与校准由操作者核实，不由CSV自动证明。
- 逐对r=(target−background)/(reference−background)，输出比值的均值、n−1样本标准差、s/√n。单次测量的两种离散度输出null；不把null当作零。
- r>1会在ratios_above_one计数但不自动删点，需核对参考定义、漂移、单位和校准。输出本身不决定应命名η_sys还是η_rel。
- 不自动修正光源漂移、衰减器/透镜损耗；未合成校准、背景与相关性等不确定度。不要将A类标准不确定度写成完整误差条。

### image：二维相机相对量

raw/dark/mask/可选target均为无标题的矩形数字CSV；行=y，列=x。原始图像到CSV的转换及位深/线性保真须在内网用本机工具另验，本包没有读取加密文档或相机专有格式的转换器。

- raw/dark为相同采集条件下非负DN，形状相同；不进行曝光/增益归一化或平场校正。
- mask仅0/1，至少一个选中像元；只代表目标ROI，全帧是FOV分母。ROI必须由实际规则提供。
- 净信号为raw−dark。出现负值会保守拒绝，不自动截零；请保留原始数据并在独立方法中讨论噪声/偏置，不能为通过脚本任意修改数据。
- --saturation填写真实原始DN的饱和阈值；raw≥阈值拒绝。未给则`saturation_checked=false`，不能声称未饱和。样例255纯属合成条件。
- 输出净全帧/ROI的DN之和、帧内ROI比例及ROI强度加权质心（零基像元中心）。这些不是功率W或绝对效率；像元面积一致才可直接求比例。需要物理距离时另用已标定像元/放大率转换。
- target是非负目标强度且形状相同。NRMSE_norm_full_frame在整个帧内分别归一化后比较，公式见MODULE-005，掩膜不参与其比较域；无配准/插值/去噪/拟合。若需比较信号域，应先有可追溯的统一裁剪，重新冻结输入。

### spots：等权目标光斑积分

无标题矩形CSV，所有元素展平视为不同光斑的净积分；至少2个值，均有限非负，均值>0。需事先完成背景扣除和固定ROI积分。输出CV_spot_sample、U_range；它们不是时间重复性。非等权目标需先按目标权重作有记录的转换，本脚本不猜权重。

### GS/DFT演练

`gs_scalar_demo.py`使用正交归一的二维离散傅里叶变换（教学用直接求和，非FFT），限制size≤32以控制计算量。验证DFT逆变换、Parseval能量、线性相位斜坡的已知频点[行1,列2]，以及GS单目标频点的简单可解析情形。所有频点为未fftshift索引，不带实际λ/f/像元尺寸。

它不读真实DOE相位、不模拟透镜孔径/离焦、不输出真实光斑宽度，也不是独立传播验证或任意图样收敛证明；真实相位设计与标量模型按MODULE-002/003在内网复现。

## 预期合成答案

- 功率：[0.4,0.6]，均值0.5，样本标准差√0.02，均值A类标准不确定度0.1；非器件效率。
- 图像：净全帧6DN、目标ROI4DN、ROI比例2/3、ROI质心(x,y)=(1,1)像元、同目标NRMSE=0。
- 光斑：[2,4]，样本CV=√2/3，U_range=2/3。
- GS：解析峰位置[1,2]，单位输入能量的输出能量约1，逆变换和末次单点振幅误差<1e−10。该阈值仅用于合成数学基准，不是实验合格标准。

合成演练状态与已执行命令见 ../state/VALIDATION.md。目标机未实测项必须记为“内网待验证”。真实运行应另存输入摘要、参数、软件版本、时间、输出与失败日志。

## research-v2接口说明

Python/Conda准备见../SETUP-CONDA.md。新增光瞳背景没有改变脚本依赖或算法；σ/共轭映射/多极分割等仅为MODULE-006的方法建议，尚未实现或验证。REF-006来源软件不需安装。
