# STATUS — report-001 / research-v2

更新：2026-10-29（Asia/Shanghai）；外网公开准备阶段。

| 项目 | 状态 | 证据与恢复位置 |
| --- | --- | --- |
| 任务建立/边界 | 已记录 | task.md |
| 理论/方法来源 | 官方实现已查阅；原始论文全文缺口 | references/SOURCES.md、REF-006笔记、Q-011 |
| MODULE-001至006 | 外网草拟，待内网适配 | modules/、ENTRY模块索引 |
| 原理示意图 | 原创示意；非实际装置图 | assets/FIG-001-optical-path.svg；FIG-005-pupil-context.svg/png |
| 离线计算与合成演练 | 见逐项实测记录 | analysis/、state/VALIDATION.md |
| 真实模板/设计/数据/照片 | 未接入 | Q-001至010 |
| 实验结果、结论与指标判定 | 未撰写/待材料 | 不以合成样例代替 |
| 内网读写/保存重开/视觉排版 | 待目标机验证 | guidance/docs/03-internal.md |

恢复摘要：先按ENTRY校验包和本机规程，再读取实际模板、生成模板约定与内容映射，取得真实输入并选择指标。每章实际写作时建立其CH-ID记录，绑定DATA/IMG/REF与图表ID。来源笔记中的自写摘要可以离线查阅，外部链接失败不能改写成已读原文。后续合稿不能把当前“外网草拟”升级成“实验已通过”。

research-v2新增：投影光刻照明光瞳背景与坐标/评价边界、REF-006、FIG-005、Conda说明；见CHANGES-v2.md。Q-012光瞳映射与Q-013系统收益仍待内网界定，实际结果空缺。

本版本复跑：8项合成测试与power/image/spots/GS四个CLI通过，结果与已知答案一致；背景资料与FIG-005已检查。详见VALIDATION.md。
