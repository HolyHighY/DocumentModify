# 来源清单与查阅范围

查阅日期：2026-10-29（Asia/Shanghai）。检索路径：从GS/标量光学及光刻成像的官方开源实现、作者讲义和文档查阅其原始文献链接，并核对相关函数及许可。本次没有可用通用文献检索工具，未作全网或系统综述。来源并非该DOE器件的性能证据。

| ID | 来源及版本 | 实际查阅/质量与用途 | 支持位置与离线定位 |
| --- | --- | --- | --- |
| USER-001 | 用户本次公开任务描述 | 已读；仅支持任务事实，不支持实测数值 | task.md及MODULE-001 |
| USER-002 | 用户新增应用背景：投影光刻照明系统的光瞳整形 | 已读；支持应用目标，不支持器件/系统实际性能 | MODULE-001/006 |
| USER-003 | 用户此前提出Conda环境配置需求 | 已读；配置命令为建议，内网未执行 | SETUP-CONDA.md |
| REF-001 | slmsuite维护者Holodyne Labs，Hologram算法源码；提交5ac5a19ac356fe238a54db8a0a6be7114f085cf8 | 已查阅官方实现及README；软件一手证据，非GS原始论文全文。SLM实验功能不等于静态DOE测试能力 | notes/REF-001.md；snapshots/REF-001-gs.txt；函数optimize、optimize_gs、振幅替换 |
| REF-002 | Eric Bezzam，waveprop；提交84c3e7dd50c7193e4c069a7581740ecbf33a3167 | 已查阅README与Fraunhofer/Fresnel/角谱源码；软件一手证据，教材在README列出但本次未取得教材全文 | notes/REF-002.md；snapshots/REF-002-*.txt |
| REF-003 | LightPipes Developers，LightPipes；提交cd965c9469bb53bbae2bf185d38c1107408cd5b5 | 已查阅官方manual与lenses.py；支持薄透镜相位与焦面FFT标度 | notes/REF-003.md；snapshots/REF-003-lens.txt |
| REF-004 | GS原始论文候选PDF，链接来自REF-001的optimize文档 | 请求返回HTTP403，未读全文；标题/页码等书目待核对，不列作已核实正式引用 | notes/REF-004-005-access-gap.md；Q-011 |
| REF-005 | Fienup算法比较论文候选公开PDF | 请求返回HTTP403，未读全文，不承担已核实论断 | 同上；Q-011 |
| REF-006 | Chen、Geng、Yu、Pan作者讲义（2024-03-06）及TorchOPC/TorchLitho官方源码；提交027cf8a9ec3ebda3b0ae9902313d7c856e67af03 | 实际查阅讲义第1、11–12、15–17页与Source/ProjectionObjective/ImagingModel/Calculate2DAerialImage；支持照明源、掩模与投影系统的联合成像模型，未运行该软件 | notes/REF-006-lithography.md；provenance.json中REF-006各文件记录；离线自写摘要，不含原文/代码 |

精确URL、全文源文件SHA256与节选行号见 `provenance.json`。本包自写理论摘要和方法建议可离线阅读；少量官方实现节选附上游许可。slmsuite源码固定版本与main下载件SHA256一致；MIT许可来自规范维护仓库main于同日的下载，未将许可文件单独声称固定到该提交。waveprop与LightPipes的许可对应下载到的固定版本。

不携带未取得授权的论文/教材全文；不复制第三方图片。示意图为本包原创。已有材料不足以支持真实实验结果或“模型适用性已确认”的结论。

## 来源之间的口径检查

- slmsuite提供基本GS及多种加权/反馈变体；本报告用户只确认GS，不自动改写为WGS或相机闭环算法。
- waveprop的自由传播Fraunhofer距离z与LightPipes的透镜焦距f具有不同几何含义；MODULE-003分开处理。
- 薄透镜和标量传播均是模型；源代码可帮助核对公式与采样，但不提供本器件的材料/加工/校准信息。
- 相机“效率”、目标功率/输入功率和帧内ROI比例可能使用不同分母；本包保留各自定义，不直接抄软件统计名。

research-v2补充：REF-006为讲义/软件一手模型资料，不是本器件测试或整机验证。ASML与TU Wien候选页面本次均403，未读正文，未用作背景论据；细节见REF-006笔记。照明光瞳与晶圆像面、单位相干传播与部分相干成像的范围分别处理，见MODULE-006。
