# 原始文献访问缺口

2026-10-29实际请求记录：

| ID | 请求URL | 结果 | 能力边界 |
| --- | --- | --- | --- |
| REF-004 | https://www.u.arizona.edu/~ppoon/GerchbergandSaxton1972.pdf | curl退出22 / HTTP403 | 未下载全文；入口来自REF-001的GS文档链接（原链接http，本次以https请求）；书目信息待原文核对 |
| REF-005 | https://labsites.rochester.edu/fienup/wp-content/uploads/2019/07/AO82_PRComparison.pdf | curl退出22 / HTTP403 | 未下载全文；这是算法比较论文候选路径，不代表已核实文件存在或正文内容 |

未取得响应体以诊断403原因，不能据此断言是作者权限、文件失效还是环境网络策略。未绕过访问控制或关闭TLS。包内不含这两篇全文，也没有伪造页码、DOI或原文摘录。

在允许的渠道取得合法全文后，可由内网AI核实题名、作者、刊物、年份、页码和支持位置，再建立正式引用。当前GS流程以REF-001官方软件一手说明为证据，传播关系以REF-002/003为证据。若正式报告要求原始论文支撑，则Q-011仍需解决。
