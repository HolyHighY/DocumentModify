# REF-006 — 光刻成像与照明分布：查阅笔记（自写摘要）

查阅日期：2026-10-29。公开作者项目：https://github.com/TorchOPC/TorchLitho 。固定提交：027cf8a9ec3ebda3b0ae9902313d7c856e67af03。完整URL、源文件SHA256及查阅位置见references/provenance.json的REF-006记录。

## 作者讲义

题名：Differentiable Computational Lithography Framework。
作者：Guojin Chen、Hao Geng、Bei Yu、David Z. Pan；封面日期March 6, 2024。此处引用的是实际取得的作者讲义，不把README列出的论文当作已取得论文全文。
文件：misc/slides/torchlitho.pdf；查阅PDF物理页第1、11、12、15–17页（第11–12页页脚分别11/30、12/30）。

- 第11页：在部分相干照明下，以掩模物函数、投影传递函数和互强度描述像面强度。关键含义是照明相干/权重条件与物和投影系统共同参与，而非仅以输入总功率确定图形像。
- 第12页：Abbe表述将与照明源方向相关的相干像强度按源分布J积分；Hopkins表述通过TCC联系不同掩模频谱分量。MODULE-006仅用自写的加权强度积分说明这层关系，没有运行完整成像模型。
- 第15–17页：示意Source—Lens—Mask—Projection Lens—Wafer的投影链路。该示意不是本项目实际光路；本包FIG-005为独立原创概念图，没有复制讲义图像。

## 源代码核对（只查阅，不运行、不复制代码）

- src/models/litho/Source.py：Source类约20–38行定义照明形态与SigmaIn/Out等参数；Calc_SourceAll约80–179行按annular/dipolecirc/multipole等分支生成源；CalculateAnnularSourceMatrix约474–484行用径向内外界确定环形支持域。
- src/models/litho/ProjectionObjective.py：ProjectionObjective初始化约6–17行独立定义投影物镜参数，与Source分离，支持“照明源分布不同于投影光瞳”的概念辨析。
- src/models/litho/ImagingModel.py：约24–75行组合Source、Mask与Projector并调用Abbe/Hopkins分支。
- src/models/litho/functions/Calculate2DAerialImage.py：约29–35行取得源与投影参数；约71–84行针对源位置处理掩模谱与有效瞳域；约133–145行对各源点形成的强度按sourceV加权并求和。

以上只是源代码结构查阅，未证明数值实现普遍正确，也未运行TorchLitho。代码默认值不得作为本项目波长、NA、缩小倍率或光瞳形态。该项目的矢量或工艺模块也不构成本包验证结果。

## 权利与证据范围

本次下载的LICENSE内容为GPL v3，README末尾也指向GPL3.0；不以README中的MIT徽标认定完整许可。本包不分发该软件源码、讲义全文或第三方图，仅携带本文件的自写事实摘要和来源定位。若之后需要部署软件，应另行评估其依赖、许可与目标机兼容性；本包依然仅需Python标准库。

## 其他来源的访问限制

本次另请求 https://www.asml.com/en/technology/lithography-principles 与 https://www.iue.tuwien.ac.at/phd/kirchauer/node24.html ，均返回HTTP403，未读到正文，未用于支持背景论断。未取得403原因诊断，不能断言具体拒绝原因。原REF-004/005的论文全文缺口仍保留。

## 本包推论边界

“本DOE用于照明光瞳整形”来自USER-002；“如何将台架结果解释为光瞳、如何选择指标”是本包据上述模型及REF-002/003传播关系提出的分析建议，需真实标定与数据验证。没有据公开示例推断本器件的工艺适用波段或系统成像收益。
