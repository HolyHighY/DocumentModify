# 内网先配置Python环境

本包仍只依赖Python标准库。推荐Python 3.12，外网已实测3.12.14；本次没有在内网执行Conda创建环境，也未验证内网软件源或包缓存。

## 已有可用内网Conda软件源

```sh
conda create -n doe-report python=3.12 -y
conda activate doe-report
python --version
```

已有同名环境时先查看/激活，不覆盖或删除原环境。这里的安装渠道应使用内网已批准配置的软件源。

## 无法连接软件源

```sh
conda create --offline -n doe-report python=3.12 -y
conda activate doe-report
python --version
```

这要求Conda缓存已包含与内网OS/CPU架构匹配的Python3.12和依赖；只有Conda本身不保证缓存齐全。若缺包，从允许的渠道准备适配的离线Conda包，不将外网Linux包直接当作Windows包，也不关闭校验。

## 激活后，从解压的research-v2包根目录验证

```sh
python -B guidance/tools/document_check.py verify --root . --manifest MANIFEST.json
python -B -m unittest discover -s analysis -p test_analysis.py -v
```

要求摘要校验退出0，8项合成测试通过。验证通过后按ENTRY.md继续，分析命令见analysis/README.md，输出写包外新目录。实际模板、加密文件、WPS读写、相机专有格式和视觉排版不由这两项检查证明。

REF-006的TorchLitho只是背景查阅来源，本包没有引入其PyTorch或其他依赖；若后续另做完整光刻成像仿真，应作为独立工作配置和验证。
