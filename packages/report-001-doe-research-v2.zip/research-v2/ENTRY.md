# ENTRY — report-001 / DOE实验测试报告 / research-v2

资料日期：2026-10-29。当前阶段：外网公开理论与方法准备；不是实验结果报告。
模板状态：仅内网可见，内网接入后解析。以下四部分来自用户的常见报告框架，不是模板解析结果。

## 阅读顺序与模块索引

1. `task.md`：用户事实、任务边界与默认假设；当前应用为投影光刻照明系统光瞳整形。
2. `state/STATUS.md`、`state/QUESTIONS.md`：进度、缺口与责任。
3. `outline.md`、`glossary.md`：暂定覆盖结构与指标口径。
4. 按需要读取以下模块，均含可直接改写的中文草稿：

| ID / 路径 | 用途 | 主要证据 | 内网先补什么 |
| --- | --- | --- | --- |
| MODULE-001 `modules/01-purpose-and-route.md` | 投影光刻应用背景、实验目的与技术路线 | USER-001/002；REF-001/002/003/006 | 目标光瞳、指标与样品 |
| MODULE-006 `modules/06-lithography-pupil-context.md` | 光瞳/场面/像面、部分相干成像、坐标与评价边界 | REF-006；USER-002；REF-002/003 | 光瞳映射标定、NA与系统模型范围 |
| MODULE-002 `modules/02-gs-design.md` | GS设计、约束和可复现记录 | REF-001 | 设计文件、入射振幅、目标、迭代记录 |
| MODULE-003 `modules/03-scalar-model.md` | 标量传播、透镜、物理采样与验证 | REF-002/003 | 波长、几何、孔径、相位文件 |
| MODULE-004 `modules/04-measurement-plan.md` | CMOS/功率计测量方案 | USER-001；本包建议协议 | 实际设备、校准与操作日志 |
| MODULE-005 `modules/05-analysis-and-discussion.md` | 指标、统计、不确定度与讨论 | 本包显式定义；REF-001/002/003仅作理论背景 | 原始数据与基准定义 |

来源索引和离线证据：`references/SOURCES.md`、`references/notes/`、`references/snapshots/`。
图：`assets/FIG-001-optical-path.svg`（单器件测试）及`assets/FIG-005-pupil-context.svg/png`（应用关系）；均为原创概念/原理示意，非实际装置图。
脚本与运行方法：`analysis/README.md`，只依赖Python 3标准库；不联网、不下载字体或模型。
通用规范：`guidance/`，先读START、通用和内网规范；任务类型为实验报告。

## 本包已完成与未完成

本次新增：投影光刻照明光瞳整形背景、REF-006作者讲义/源码查阅笔记、MODULE-006、FIG-005、Conda配置步骤；具体变更见`state/CHANGES-v2.md`。
已完成：一手开源实现/光刻讲义查阅、理论/方法草稿、原理图、输入约定和离线分析脚本；合成测试结果见 `state/VALIDATION.md`。
来源限制：GS原论文和Fienup论文链接返回403，未读全文；不以它们承担已核实论断。使用已查阅的官方实现和带行号的离线节选作为当前方法证据。未作全面文献综述。
所有CSV和数值示例均在 `analysis/synthetic/`，不属于该DOE实测；没有实际器件结果、实验照片、合格判定或最终模板大纲。
未验证假设：相干/单色、相位型薄元件、透镜后焦面、标量和傍轴近似；须用内网材料核对。光瞳类型/参数、测试面共轭映射及NA口径见Q-012；系统成像收益见Q-013，未作验证。

## 内网接收与继续

先按`SETUP-CONDA.md`激活合适Python环境；本包仍仅依赖标准库，推荐Python3.12。Conda安装步骤未在内网执行，离线创建需已有适配包缓存。

1. 从可信渠道取得完整 `research-v2` 文件夹或其压缩包；压缩包解压到新目录，不覆盖既有材料。
2. 在包根目录执行 `python guidance/tools/document_check.py verify --root . --manifest MANIFEST.json`，必须退出0。Windows仅有启动器时用 `py -3`。
3. 读取所选内网环境有效的 `LOCAL-WORKFLOW.md`、`qualification/RESULTS.md` 和相关问题记录；条件未变复用，只对缺失/变化能力补验。不要把外网测试当作内网资格验证。
4. 将接收包原样保留到 `.local/projects/report-001/incoming/research-v2/`，后续工作另存 `work/`。合成材料不得进入正式结果。
5. 在内网读取真实模板副本，建立 `work/template-contract.md`；再将模块、原始数据和照片映射到 `work/content-map.md`，据真实模板确定最终大纲。
6. 本地解决 `state/QUESTIONS.md` 的关键项，确认测试面至照明光瞳的共轭/角度映射（Q-012），确定功率参考平面/ROI/坐标与误差口径后再处理数据；遵照已验证的本机读写路线写入副本。
7. 用合成CSV复跑脚本及其测试，再接入真实数据。每张结果图记录材料ID、脚本版本、单位和预处理；补原始文件摘要。
8. 分章维护 `work/STATUS.md`；完成证据、内容、模板、保存重开与逐页视觉检查后才能定稿。

资料流向：只把本次公开准备包带入内网。内网模板、真实数据、实验照片、工作日志、凭据和内网生成内容留在内网；不得把整个 `.local` 作为交接包或上传GitHub。
`MANIFEST.json`证明文件一致性，不证明来源可信或理论正确。修改包内容会使冻结版本失效；工作副本或新版本另存并重新生成摘要。
