# 知识模块与暂定结构

| 模块 | 研究问题 | 入口 | 支持来源/限制 |
| --- | --- | --- | --- |
| MODULE-001 | 材料寿命证据支持什么 | chapters/report.md §2–3；references/evidence.md | [1–3]；缺193 nm晶体石英直接对照 |
| MODULE-002 | 是否承担偏振功能 | chapters/report.md §4 | [4]；532 nm概念，不替代目标DOE |
| MODULE-003 | 为什么必须重算相位 | chapters/report.md §5；analysis/calculations.py | 薄相位推导及未核实物性示例 |
| MODULE-004 | 怎样形成可比较验证 | chapters/report.md §6–7 | AI建议，未执行 |

这些模块按问题组织；内网读真实模板后可保留、改写、拆分或舍弃。§1/8和参考文献提供范围、结论边界与缺口。暂定标题不是来自内网模板。

术语：fused silica=非晶熔融石英；crystalline quartz=晶体石英；CaF₂=氟化钙；DOE=衍射光学元件；F=单脉冲能量密度；I=辐照度；I₁₀₀₀/I₁=特定脉冲数阈值比，不是存活概率。
