"""Recheck illustrative arithmetic only; inputs are NOT validated material data."""
import json
wl=193.0
fs=wl/(1.5607-1)
rows=[{"n":n,"h_2pi_nm":wl/(n-1),"reduction_percent":100*(1-wl/(n-1)/fs)} for n in (1.5607,1.661,1.675)]
assert abs(fs-344.21259140360265)<1e-8
assert abs(321.1*0.0003-0.09633)<1e-12
print(json.dumps({"status":"illustrative_inputs_unverified","depths":rows,"rotation_300nm_deg":321.1*0.0003,"rotation_0_28mm_deg":321.1*0.28},indent=2))
