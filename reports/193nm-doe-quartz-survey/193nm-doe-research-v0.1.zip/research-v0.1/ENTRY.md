# ENTRY：193 nm DOE材料替换研究初稿

- 项目：193nm-doe-quartz-survey；阶段：外网定向复核与背景初稿v0.1；中文研发选型读者及研究范围已由用户确认。
- 阅读顺序：task.md → modules/index.md → chapters/report.md → references/evidence.md → state/handoff.md。
- 正文为可重组的知识背景，不是内网模板的最终章名；真实模板待内网解析。最终交付模式未确认，默认word；不得将本Markdown初稿自动视为md-only选择。
- 已完成：四篇原文关键文字和实验条件复核；示例算术复算。未独立实验、未全面检索、未完成器件认证或Word版面验收。
- references/evidence.md提供可离线阅读的作者自写证据摘要及限制；未包含源PDF、用户原始参考稿或仓库完整.local目录。源PDF在当前项目incoming内保留，可在有相应携带权限时另行提供，不默认随包分发。
- 示例物性输入未核实，不得当实际处方；正文背景条件来自参考稿且未确认，详见state/handoff.md。
- 运行环境：Python 3标准库。在本包根目录运行 python3 analysis/calculations.py；无需联网。
- 接收校验：python3 guidance/tools/document_check.py verify --root . --manifest MANIFEST.json。不要重新生成清单来覆盖差异。
- 内网按有效本机规程和交付模式补验，再读取真实模板、建立章节映射。材料与日志不向外发送，公开研究包由外网单向带入内网。
- 本包只在当前外网环境做完整性与离线脚本验证，实际断网目标机待验证。MANIFEST仅证明一致性，不证明事实正确或来源可信。
